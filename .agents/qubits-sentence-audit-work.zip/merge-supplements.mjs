import {writeFile,readFile} from 'node:fs/promises';
import {loadLines,load,validateShard} from './validate.mjs';
const dir='/tmp/qubit-sentence-audit-qxy8gew0';
const n=Number(process.argv[2]);
const cuts={2:'s001028',9:'s005260',12:'s007050',13:'s007679',22:'s013016'};
let rows;
if(n===6){rows=(await Promise.all(['6a','6b','6c'].map(x=>loadLines(`supplement-scores-${x}.jsonl`)))).flat();}
else{
 const tag=String(n).padStart(2,'0');
 const raw=await readFile(`${dir}/scores-${tag}.jsonl`,'utf8');
 const prefix=raw.trim().split('\n').map(JSON.parse);
 if(prefix.some(r=>r.id>cuts[n]))throw Error('Original scorer exceeded agreed ownership');
 await writeFile(`${dir}/prefix-scores-${n}.jsonl`,raw);
 rows=[...prefix,...await loadLines(`supplement-scores-${n}.jsonl`)];
}
const ids=rows.map(r=>r.id),expected=await load(`shard-${String(n).padStart(2,'0')}-ids.json`);
if(ids.length!==expected.length||new Set(ids).size!==ids.length||expected.some(id=>!ids.includes(id)))throw Error('Merge ID mismatch');
rows.sort((a,b)=>a.id.localeCompare(b.id));
await writeFile(`${dir}/scores-${String(n).padStart(2,'0')}.jsonl`,rows.map(r=>JSON.stringify(r)).join('\n')+'\n');
const result=await validateShard(n);
if(result.issues.length)throw Error(JSON.stringify(result.issues));
console.log(JSON.stringify({shard:n,count:rows.length,issues:result.issues}));
