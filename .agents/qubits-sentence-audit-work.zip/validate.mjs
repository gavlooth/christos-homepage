import {readFile} from 'node:fs/promises';
const dir='/tmp/qubit-sentence-audit-qxy8gew0';
export const load=async name=>JSON.parse(await readFile(`${dir}/${name}`,'utf8'));
export const loadLines=async name=>(await readFile(`${dir}/${name}`,'utf8')).trim().split('\n').map(JSON.parse);
export async function validateShard(n){
 const tag=String(n).padStart(2,'0');
 const rows=await loadLines(`scores-${tag}.jsonl`);
 const expected=await load(`shard-${tag}-ids.json`);
 const ids=rows.map(r=>r.id);
 const issues=[];
 if(ids.length!==new Set(ids).size||ids.length!==expected.length||expected.some(id=>!ids.includes(id)))issues.push('ID coverage mismatch');
 for(const r of rows){
  if(!Number.isInteger(r.readability_score)||r.readability_score<1||r.readability_score>5)issues.push(`Readability ${r.id}`);
  if(!((r.rigor_score===null&&r.rigor_status==='not_applicable')||(Number.isInteger(r.rigor_score)&&r.rigor_score>=1&&r.rigor_score<=5&&r.rigor_status==='assessed')))issues.push(`Rigor ${r.id}`);
  for(const key of ['readability_reason','rigor_reason'])if(typeof r[key]!=='string'||r[key].trim().length<12)issues.push(`${key} ${r.id}`);
  if(!['high','medium','low'].includes(r.confidence)||!Array.isArray(r.flags))issues.push(`Metadata ${r.id}`);
 }
 return {shard:n,rows,issues};
}
