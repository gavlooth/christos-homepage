import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {load,loadLines,validateShard} from './validate.mjs';
const root='/home/heefoo/Documents/code/christos-cloudflare-page';
const dir='/tmp/qubit-sentence-audit-qxy8gew0';
const source='notes/pages/defects-to-topological-qubits.html';
const hash=b=>createHash('sha256').update(b).digest('hex');
const snapshot=await readFile(`${dir}/source.html`);
if(hash(await readFile(`${root}/${source}`))!==hash(snapshot))throw Error('Manuscript changed');
const scores=new Map();
const contexts=new Map();
for(let n=1;n<=24;n++){
 const result=await validateShard(n);
 if(result.issues.length)throw Error(JSON.stringify(result.issues));
 for(const r of result.rows){if(scores.has(r.id))throw Error(`Duplicate global ID ${r.id}`);scores.set(r.id,r);}
 for(const p of await loadLines(`shard-${String(n).padStart(2,'0')}.jsonl`))contexts.set(p.passage_id,p);
}
const input=await loadLines('sentences.jsonl');
if(scores.size!==input.length)throw Error('Global coverage mismatch');
const corrections=await load('parent-corrections.json');
for(const [id,patch] of Object.entries(corrections)){if(!scores.has(id))throw Error(`Unknown correction ${id}`);scores.set(id,{...scores.get(id),...patch});}
const fields=['readability_score','readability_reason','rigor_score','rigor_status','rigor_reason','confidence','flags'];
const rows=input.filter(s=>!/^sources(?:-\d+)?$/.test(s.section_id||'')).map(s=>{
 const score=scores.get(s.id);if(!score)throw Error(`Missing ${s.id}`);
 if(hash(s.text)!==s.source_text_sha256)throw Error(`Text hash ${s.id}`);
 const context=contexts.get(s.passage_id);
 return {...s,paragraph_context:context.paragraph,...(s.kind==='table_entry'?{table_headers:context.table_headers,table_row_context:context.table_row_context}:{}),...Object.fromEntries(fields.map(k=>[k,score[k]]))};
});
const summary=await load('summary-base.json');
summary.assessment.parent_corrections=Object.keys(corrections);
const distribution=(items,key)=>Object.fromEntries([1,2,3,4,5,null].map(n=>[n===null?'not_applicable':String(n),items.filter(r=>r[key]===n).length]));
summary.created_at=new Date().toISOString();
summary.audit_file='.agents/qubits-sentence-audit.jsonl';
summary.coverage.final_records=rows.length;
summary.distributions={readability:distribution(rows,'readability_score'),rigor:distribution(rows,'rigor_score')};
summary.assessment.rejected_examples='Some low-rigor propositions are deliberately rejected by the manuscript. Records flagged rejected_claim_example rate the proposition itself, not the correctness of the manuscript\'s rejection. Read paragraph/table context before treating a score as a manuscript defect.';
summary.assessment.validation='All 24 shards: exact ID coverage, no duplicate IDs, score/status ranges, nonempty reasons, immutable text hashes; source unchanged. Parent inspected systematic samples from each shard and returned detected template/context errors for correction.';
summary.units=[...new Set(rows.map(r=>r.unit_id))].map(id=>{const u=rows.filter(r=>r.unit_id===id);return {unit_id:id,unit_title:u[0].unit_title,records:u.length,readability:distribution(u,'readability_score'),rigor:distribution(u,'rigor_score')};});
summary.calibration_records=rows.filter(r=>['s000061','s000063','s000065'].includes(r.id));
summary.low_score_index=rows.filter(r=>r.readability_score<=2||(r.rigor_score!==null&&r.rigor_score<=2)).map(r=>({id:r.id,unit_id:r.unit_id,readability_score:r.readability_score,rigor_score:r.rigor_score,rejected_example:r.flags.includes('rejected_claim_example')}));
const output=rows.map(r=>JSON.stringify(r)).join('\n')+'\n';
await writeFile(`${root}/.agents/qubits-sentence-audit.jsonl`,output);
summary.audit_sha256=hash(output);
await writeFile(`${root}/.agents/qubits-sentence-audit-summary.json`,JSON.stringify(summary,null,2)+'\n');
const reread=(await readFile(`${root}/.agents/qubits-sentence-audit.jsonl`,'utf8')).trim().split('\n').map(JSON.parse);
if(reread.length!==rows.length||hash(await readFile(`${root}/${source}`))!==hash(snapshot))throw Error('Final verification failed');
console.log(JSON.stringify({records:rows.length,bytes:Buffer.byteLength(output),distributions:summary.distributions,calibration:summary.calibration_records.map(r=>({id:r.id,readability:r.readability_score,rigor:r.rigor_score})),source_unchanged:true},null,2));
